<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'مكافحة الاختراق';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_list']        = 'قائمة';

// Column
$_['column_name']      = 'الاسم';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل!';