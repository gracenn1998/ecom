<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']        	 = 'اوبن كارت';

// Text
$_['text_profile']           = 'ملفك الشخصي';
$_['text_store']           	 = 'المتاجر';
$_['text_help']            	 = 'مساعدة';
$_['text_homepage']        	 = 'موقع اوبن كارت';
$_['text_support']         	 = 'منتدى الدعم الفني';
$_['text_documentation']   	 = 'تعليمات';
$_['text_logout']          	 = 'خروج';
